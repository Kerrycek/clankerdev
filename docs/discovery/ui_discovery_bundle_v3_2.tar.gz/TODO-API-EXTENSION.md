# TODO: API extensions needed for the new vpsAdmin Web UI

This document tracks small, UI-driven API additions that will make the new responsive Web UI simpler, faster, and more reliable.

It is intentionally written as an implementation checklist.

## 1) Persist per-user Web UI settings (JSON)

### Goal
Store UI preferences per authenticated user (and allow admins to read/update per-user settings when needed), without embedding UI state into the existing `users` table.

Examples of settings we want to persist:

- `ui_mode`: `"novice" | "classic"`
- `theme`: `"system" | "light" | "dark"`
- `sidebar`: collapsed/expanded, pinned/unpinned
- `tables`: per-table column visibility/order, density, default sort
- `vps_detail`: which panels are pinned/expanded by default
- `confirmations`: per-action confirmation preferences (where appropriate)
- `last_workspace`: `"user" | "admin"` (for admins)

### Proposed DB schema
Create a new table, one row per user:

- `user_ui_settings`
  - `user_id` (PK, FK to `users.id`, NOT NULL)
  - `settings_json` (TEXT, NOT NULL) — JSON string
  - `created_at` (DATETIME/TIMESTAMP)
  - `updated_at` (DATETIME/TIMESTAMP)

Notes:

- Keep it as `TEXT` (not JSONB) unless the backend already prefers JSONB.
- Enforce `user_id` uniqueness (1 row per user).
- Default to `{}`.

### Proposed API surface
Expose settings as a dedicated resource (preferred):

- `UserUiSetting` (singular)
  - `Show` (GET) — returns current user's settings JSON
  - `Update` (PUT/PATCH) — replaces/patches settings JSON

Admin capability (optional but useful):

- `UserUiSetting` could accept a `user` parameter for admin use, or
- nest it under `User` (e.g., `User::UiSetting`), where:
  - normal users can only access their own
  - admins can access any user

Minimal payload:

- Input:
  - `settings_json` (TEXT) or `settings` (object)
- Output:
  - `settings_json` or `settings`
  - `updated_at`

### Validation & compatibility
- The API should not try to validate/understand every setting key.
- It should validate that the JSON is syntactically valid.
- For forward compatibility, the UI must tolerate unknown keys.

---

## 2) Optional: a lightweight capability endpoint

### Goal
Allow the UI to quickly determine:

- current user info (id, login, level, role)
- whether the user can access admin workspace
- enabled authentication factors (TOTP / WebAuthn) and SSO state

This can reduce UI boot time by avoiding multiple calls.

### Proposed API surface (example)
- `User::Current` output can be extended or a new action can exist:
  - `User::Me` / `User::Capabilities` (GET)

---

## 3) Optional: server-driven navigation hints

### Goal
As the API grows, help the UI maintain “discoverability” without generating the whole UI from the API description.

Potential approach:

- Add optional metadata fields to resources/actions (tags like `"dns"`, `"storage"`, `"vps"`, `"admin"`) that the UI can use for grouping.

This is optional; the UI can maintain its own module mapping initially.
